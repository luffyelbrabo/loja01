import 'dotenv/config'
import express from 'express'
import bodyParser from 'body-parser'

import GNRequest from './apis/gerencianet'

const app = express()

app.set('view engine', 'ejs')
app.set('views', 'src/views')

app.use(bodyParser.json())

const reqGNAlready = GNRequest({
  clientId: process.env.GN_CLIENT_ID,
  clientSecret: process.env.GN_CLIENT_SECRET,
})

app.get('/', async (req, res) => {
  const reqGN = await reqGNAlready

  const dataCob = {
    calendario: {
      expiracao: 300,
    },
    valor: {
      original: '100.00',
    },
    chave: 'aa5530b4-7aea-4f1f-af58-810af2bdf327',
    solicitacaoPagador: 'Informe o número ou identificador do pedido.',
  }

  const cobResponse = await reqGN.post('/v2/cob', dataCob)

  const qrcodeResponse = await reqGN.get(
    `/v2/loc/${cobResponse.data.loc.id}/qrcode`
  )

  res.render('qrcode', {
    qrcodeImage: qrcodeResponse.data.imagemQrcode,
  })
})

app.get('/cobrancas', async (req, res) => {
  const reqGN = await reqGNAlready

  const cobResponse = await reqGN.get(
    '/v2/cob?inicio=2020-10-22T16:01:35Z&fim=2023-04-07T20:10:00Z'
  )

  res.send(cobResponse.data)
})

app.post('/webhook(/pix)?', (req, res) => {
  console.log(req.body)

  res.json({ status: 200 })
})

app.listen(8000, () => {
  console.log('running on: 8000')
})
