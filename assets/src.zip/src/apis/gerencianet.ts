import path from 'path'
import fs from 'fs'
import axios from 'axios'
import https from 'https'

type Credentials = {
  clientId: string | undefined
  clientSecret: string | undefined
}

const cert = fs.readFileSync(
  path.resolve(__dirname, `../certs/${process.env.GN_CERT}`)
)

const agent = new https.Agent({
  pfx: cert,
  passphrase: '',
})

const authenticate = ({ clientId, clientSecret }: Credentials) => {
  console.log('Hello')

  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString(
    'base64'
  )

  return axios({
    method: 'POST',
    url: `${process.env.GN_ENDPOINT}/oauth/token`,
    headers: {
      Authorization: `Basic ${credentials}`,
      'Content-Type': 'application/json',
    },
    httpsAgent: agent,
    data: {
      grant_type: 'client_credentials',
    },
  })
}

const GNRequest = async (credentials: Credentials) => {
  const authResponse = await authenticate(credentials)
  const acessToken = authResponse.data?.access_token

  return axios.create({
    baseURL: process.env.GN_ENDPOINT,
    httpsAgent: agent,
    headers: {
      Authorization: `Bearer ${acessToken}`,
      'Content-Type': 'application/json',
    },
  })
}

export default GNRequest
